# Брони · админ — инструкция по запуску на GitHub Pages

Приложение (`index.html`) не изменено — добавлены только 4 строки `<script>` для подключения Firebase и файла `claude-shim.js`.
Раньше база и вход работали внутри Claude; теперь их заменяет Firebase (бесплатный тариф Spark).

## Файлы
- `index.html` — ваше приложение (логика без изменений)
- `claude-shim.js` — переходник: база Firestore, вход по email/паролю, скачивание файлов
- `firestore.rules` — правила доступа к базе
- `README.md` — эта инструкция

## Шаг 1. Firebase
1. Откройте https://console.firebase.google.com → **Add project** (Google Analytics можно отключить).
2. На главной странице проекта нажмите **`</>` (Web)** → задайте имя → **Register app**. Скопируйте блок `firebaseConfig`.
3. **Build → Firestore Database → Create database** → режим *Production* → регион (например, `eur3` или `europe-west`).
4. **Build → Authentication → Get started → Sign-in method → Email/Password → Enable**.
5. Вкладка **Users → Add user** — создайте email и пароль для каждого администратора.
6. **Firestore Database → Rules** — вставьте содержимое `firestore.rules`, заменив email-адреса на настоящие (те же, что в п. 5), и нажмите **Publish**.

## Шаг 2. Настройка файла
Откройте `claude-shim.js` и в блоке `firebaseConfig` замените значения `ВСТАВЬТЕ` на данные из шага 1.2 (`apiKey`, `authDomain`, `projectId`, `appId`).
Ключ `apiKey` не секретный — защищает базу файл правил, поэтому п. 1.6 обязателен.

## Шаг 3. GitHub
1. https://github.com/new → создайте репозиторий (например, `admin`).
2. **Add file → Upload files** → загрузите `index.html` и `claude-shim.js` (`firestore.rules` и `README.md` по желанию) → **Commit changes**.
3. **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: `main`, папка `/ (root)` → Save**.
4. Через 1–2 минуты сайт откроется по адресу `https://<ваш-логин>.github.io/<имя-репозитория>/`.

## Шаг 4. Разрешить домен для входа
Firebase → **Authentication → Settings → Authorized domains → Add domain** → добавьте `<ваш-логин>.github.io`.
Без этого вход не заработает.

## Шаг 5. Первый запуск
Откройте адрес сайта → войдите email и паролем из п. 1.5 → дальше приложение работает как раньше. Вход запоминается на устройстве.

## Что отличается от версии в Claude
- Кнопка отправки резервной копии на Google Диск недоступна вне Claude — приложение покажет «скачайте файл», а скачивание копий (`.json`, `.tsv`) работает.
- Старые данные из Claude сами не переносятся: в старой версии скачайте копию (Экспорт и настройки → копия `.json`) и импортируйте её в Firestore.
